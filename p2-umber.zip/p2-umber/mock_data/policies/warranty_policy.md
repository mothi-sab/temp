# Warranty Policy

1-year warranty for functional defects.
Excludes misuse or unauthorized repairs.
