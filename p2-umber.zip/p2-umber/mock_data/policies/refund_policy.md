# Refund Policy

Customers are eligible for refunds within 30 days of delivery.
Refunds require human approval.
Partial refunds may be issued for shipping delays exceeding 10 days.
