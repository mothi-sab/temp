# Fraud Policy

Risk scoring required. High-risk orders need manual verification before monetary actions.
